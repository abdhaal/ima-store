# Marketplace — Batch 1: Auth (Customer / Seller / Admin)

## What's in this batch
- `supabase/schema.sql` — profiles table, role enum, auto-profile trigger, RLS policies
- `frontend/` — static site (plain HTML/CSS/JS, no build step) ready for GitHub Pages
  - `/customer/login.html`, `/customer/signup.html`, `/customer/dashboard.html`
  - `/seller/login.html`, `/seller/signup.html`, `/seller/dashboard.html`
  - `/admin/login.html`, `/admin/dashboard.html` — **not linked from anywhere in the UI**
  - `/css/theme.css` — dark navy + white theme
  - `/js/supabaseClient.js`, `/js/auth.js`

## Setup steps

### 1. Supabase
1. Create a project at supabase.com.
2. Open **SQL Editor** → paste and run `supabase/schema.sql`.
3. Go to **Authentication → Providers** → make sure Email is enabled.
   (For testing, you can turn off "Confirm email" under Authentication → Settings so you don't need to click a confirmation link every time.)
4. Go to **Project Settings → API** → copy your **Project URL** and **anon public key**.
5. Paste them into `frontend/js/supabaseClient.js`:
   ```js
   const SUPABASE_URL = "https://xxxx.supabase.co";
   const SUPABASE_ANON_KEY = "eyJ...";
   ```

### 2. Create your first admin
There is deliberately **no admin signup form**. To create your first admin:
1. Sign up once through `/customer/signup.html` with the email you want to use as admin.
2. In Supabase → **Table Editor → profiles**, find that row and change `role` to `admin`.
   Or run in SQL Editor:
   ```sql
   update public.profiles set role = 'admin', is_approved = true
   where id = '<paste-user-uuid-from-auth.users>';
   ```
3. Log in at `/admin/login.html` (bookmark this URL — it's not linked anywhere in the site).

### 3. GitHub Pages
1. Push this repo to GitHub.
2. Either:
   - Move everything inside `frontend/` to the repo root, **or**
   - In repo **Settings → Pages**, set the source folder to `/frontend` (if your plan supports a custom folder; otherwise move files to root, since GitHub Pages usually only serves from `/` or `/docs`).
3. Enable GitHub Pages in **Settings → Pages** → choose the `main` branch.
4. Your site will be live at `https://<username>.github.io/<repo>/`.

## How the role system works
- `profiles.role` is `customer`, `seller`, or `admin`.
- Signup forms only ever send `customer` or `seller` — the database trigger ignores any other value, so nobody can self-promote to admin from the browser.
- Every login page checks the logged-in user's role against the page they used (`handleSignIn(event, 'seller')` etc.) — a customer account can't log in through the seller page.
- Sellers start with `is_approved = false`. They can log in and see their dashboard, but it'll show "Pending approval" until an admin flips `is_approved` to `true` (the admin UI for this comes in the next batch).
- Row Level Security means even if someone edits the JS in devtools, Postgres itself refuses to hand back other people's profile rows unless the caller is an admin.

## Not included yet (next batches)
- Product catalog, search, and recommendations
- Cart + checkout + Cashfree payment integration (this needs a small serverless function on Vercel to keep your Cashfree secret key off the frontend — GitHub Pages alone can't do this since it's static-only)
- Admin panel screens (seller approval, product moderation, orders)
- Seller product management screens

Sonna, next step enna venum sollunga — product catalog/search first ah, illa admin seller-approval screen first ah, atha vachi next batch build pannuvom.
