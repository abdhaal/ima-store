// ============================================================
// Shared auth helpers used by every login/signup/dashboard page.
// Requires supabaseClient.js to be loaded first (window.sb).
// ============================================================

function showMsg(el, type, text) {
  el.className = "msg " + type;
  el.textContent = text;
  el.style.display = "block";
}

function dashboardPathFor(role) {
  if (role === "admin") return "/admin/dashboard.html";
  if (role === "seller") return "/seller/dashboard.html";
  return "/customer/dashboard.html";
}

// ---------- SIGN UP (customer or seller only — never admin) ----------
async function handleSignUp(event, role) {
  event.preventDefault();
  const form = event.target;
  const msgEl = form.querySelector(".msg");
  const btn = form.querySelector("button[type=submit]");

  const email = form.email.value.trim();
  const password = form.password.value;
  const fullName = form.full_name.value.trim();
  const storeName = role === "seller" ? form.store_name.value.trim() : null;
  const phone = form.phone ? form.phone.value.trim() : null;

  btn.disabled = true;
  try {
    const { data, error } = await window.sb.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          role, // 'customer' or 'seller' — read server-side by the DB trigger
          store_name: storeName,
          phone,
        },
      },
    });

    if (error) throw error;

    if (role === "seller") {
      showMsg(
        msgEl,
        "success",
        "Account created! Check your email to confirm, then log in. Your seller account will need admin approval before you can list products."
      );
    } else {
      showMsg(
        msgEl,
        "success",
        "Account created! Check your email to confirm your address, then log in."
      );
    }
    form.reset();
  } catch (err) {
    showMsg(msgEl, "error", err.message || "Something went wrong. Try again.");
  } finally {
    btn.disabled = false;
  }
}

// ---------- LOGIN (shared by customer/seller/admin pages) ----------
// expectedRole: 'customer' | 'seller' | 'admin'
async function handleSignIn(event, expectedRole) {
  event.preventDefault();
  const form = event.target;
  const msgEl = form.querySelector(".msg");
  const btn = form.querySelector("button[type=submit]");

  const email = form.email.value.trim();
  const password = form.password.value;

  btn.disabled = true;
  try {
    const { data: authData, error: authError } = await window.sb.auth.signInWithPassword({
      email,
      password,
    });
    if (authError) throw authError;

    const { data: profile, error: profileError } = await window.sb
      .from("profiles")
      .select("role, is_approved, full_name")
      .eq("id", authData.user.id)
      .single();

    if (profileError) throw profileError;

    // A customer can't log in through the seller page, etc.
    if (profile.role !== expectedRole) {
      await window.sb.auth.signOut();
      throw new Error(
        `This isn't a ${expectedRole} account. Please use the correct login page.`
      );
    }

    if (profile.role === "seller" && !profile.is_approved) {
      // Still let them in, dashboard.html will show a "pending approval" state
      showMsg(msgEl, "info", "Logged in — your seller account is pending admin approval.");
      setTimeout(() => (window.location.href = dashboardPathFor("seller")), 1200);
      return;
    }

    window.location.href = dashboardPathFor(profile.role);
  } catch (err) {
    showMsg(msgEl, "error", err.message || "Login failed. Check your details.");
  } finally {
    btn.disabled = false;
  }
}

// ---------- DASHBOARD GUARD ----------
// Call at the top of every dashboard page: guardPage('customer').
// Redirects to the matching login page if not authenticated / wrong role.
async function guardPage(expectedRole) {
  const { data: { session } } = await window.sb.auth.getSession();
  if (!session) {
    window.location.href = `/${expectedRole}/login.html`;
    return null;
  }

  const { data: profile, error } = await window.sb
    .from("profiles")
    .select("*")
    .eq("id", session.user.id)
    .single();

  if (error || !profile || profile.role !== expectedRole) {
    await window.sb.auth.signOut();
    window.location.href = `/${expectedRole}/login.html`;
    return null;
  }

  return profile;
}

async function logout() {
  await window.sb.auth.signOut();
  window.location.href = "/";
}
