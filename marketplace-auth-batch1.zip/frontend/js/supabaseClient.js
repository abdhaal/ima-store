// ============================================================
// Supabase client — fill these in from Project Settings > API
// ============================================================
const SUPABASE_URL = "https://YOUR-PROJECT-REF.supabase.co";
const SUPABASE_ANON_KEY = "YOUR-ANON-PUBLIC-KEY";

// window.supabase comes from the CDN script tag loaded in each HTML page,
// BEFORE this file, e.g.:
// <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
if (!window.supabase) {
  console.error(
    "Supabase library not loaded. Make sure the CDN <script> tag is included before supabaseClient.js"
  );
}

window.sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
