-- ============================================================
-- AUTH & ROLES SCHEMA (Batch 1: Customer / Seller / Admin auth)
-- Run this in Supabase SQL Editor
-- ============================================================

-- 1. Role enum
create type public.user_role as enum ('customer', 'seller', 'admin');

-- 2. Profiles table (extends auth.users)
create table public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  full_name    text,
  role         public.user_role not null default 'customer',
  phone        text,
  store_name   text,                          -- only used when role = 'seller'
  is_approved  boolean not null default true,  -- sellers start false, admin approves later
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

comment on table public.profiles is 'One row per auth.users, holds role + seller/customer specific fields';

-- 3. Auto-create a profile row whenever someone signs up
-- role + store_name are passed in from the signup form via options.data (raw_user_meta_data)
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  requested_role public.user_role;
begin
  -- Never trust the client for 'admin'. Only customer/seller can self-signup.
  requested_role := case
    when (new.raw_user_meta_data->>'role') = 'seller' then 'seller'::public.user_role
    else 'customer'::public.user_role
  end;

  insert into public.profiles (id, full_name, role, store_name, phone, is_approved)
  values (
    new.id,
    new.raw_user_meta_data->>'full_name',
    requested_role,
    new.raw_user_meta_data->>'store_name',
    new.raw_user_meta_data->>'phone',
    case when requested_role = 'seller' then false else true end
  );
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- 4. Helper: is the current logged-in user an admin? (security definer avoids RLS recursion)
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$;

-- 5. Row Level Security
alter table public.profiles enable row level security;

create policy "read own profile"
on public.profiles for select
using (auth.uid() = id);

create policy "update own profile"
on public.profiles for update
using (auth.uid() = id)
with check (auth.uid() = id and role = (select role from public.profiles where id = auth.uid())); -- can't self-promote role

create policy "admin reads all profiles"
on public.profiles for select
using (public.is_admin());

create policy "admin updates all profiles"
on public.profiles for update
using (public.is_admin());

-- ============================================================
-- 6. Create your FIRST admin manually (run once, after that user
--    has signed up once through the normal customer signup form):
--
--    update public.profiles set role = 'admin', is_approved = true
--    where id = '<paste-user-uuid-here>';
--
-- There is no public admin signup page on purpose — admin accounts
-- must always be created this way from the Supabase dashboard.
-- ============================================================
